# Lab 0 — Pipe Cleaner

**Name:**
**EID:**

Replace the placeholders below with your own answers, then delete this line.

---

## Which server did you use?

*(e.g. `mario.ece.utexas.edu` — the machine you actually compiled and ran on,
not your laptop.)*

## What inputs did you test?

*(List them. Three or four sentences is plenty. At minimum say what happened
with `sample.txt` and with empty input. If you tried anything else — negative
numbers, a file with a word in it, a very long file — say so and say what it
did.)*

## Did anything go wrong on the way?

*(Optional but useful to us. Account setup, SSH keys, cloning, `make`,
Gradescope — if one of them fought you, a sentence here helps us fix the
instructions for next year.)*

---

## Checklist before you submit

- [ ] `make` runs with **zero warnings** on the ECE server
- [ ] `./stats < sample.txt` prints `Count: 5 / Min: 62 / Max: 95 / Mean: 79.40`
- [ ] `./stats < /dev/null` prints `Count: 0` and nothing else
- [ ] No global variables; `main` only orchestrates
- [ ] The file header block at the top of `stats.cpp` is filled in
- [ ] Any AI-assisted code carries a citation comment
- [ ] Submitted `stats.cpp`, `Makefile`, and `README.md` to **Gradescope**
- [ ] Opened the Gradescope submission and confirmed the autograder ran

That last box is the actual point of this lab.
